ALTER TABLE "Project" ADD COLUMN "cancel_reason" TEXT;
ALTER TABLE "Project" ADD COLUMN "cancelled_at" TIMESTAMP(3);
ALTER TABLE "Project" ADD COLUMN "cancelled_by" TEXT;