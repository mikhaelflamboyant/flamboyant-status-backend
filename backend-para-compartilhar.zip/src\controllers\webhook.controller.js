const prisma = require('../lib/prisma')
const { notifyNewProject } = require('../services/notifications.service')
const logger = require('../lib/logger')

const freshserviceWebhook = async (req, res) => {
  try {
    const payload = req.body
    logger.info({ payload: JSON.stringify(payload) }, 'Webhook FreshService recebido')

    const title = payload.project_title || payload.subject || 'Projeto via FreshService'
    const description = payload.objetivo || payload.description_text || payload.description || 'Projeto criado via FreshService'
    const requesterEmail = payload.requester?.email || payload.email || null
    const ticketId = payload.id || payload.ticket_id || null

    const project = await prisma.project.create({
      data: {
        title,
        area: payload.area || 'Não definida',
        requester_name: payload.requester?.name || '',
        execution_type: 'INTERNA',
        description,
        go_live: null,
        traffic_light: 'VERDE',
        current_phase: 'BACKLOG',
        completion_pct: 0,
        origin: 'FRESHSERVICE',
        freshservice_ticket_id: ticketId ? String(ticketId) : null,
      }
    })

    if (requesterEmail) {
      const requester = await prisma.user.findUnique({
        where: { email: requesterEmail }
      })
      if (requester) {
        await prisma.projectRequester.create({
          data: { project_id: project.id, user_id: requester.id, type: 'SOLICITANTE' }
        })
      }
    }

    const managers = await prisma.user.findMany({
      where: {
        status: 'ATIVO',
        role: { in: ['SUPERINTENDENTE', 'ANALISTA_MASTER'] }
      }
    })

    const areaManagers = await prisma.user.findMany({
      where: {
        status: 'ATIVO',
        role: { in: ['GERENTE', 'COORDENADOR'] },
        area: 'Tecnologia da Informação'
      }
    })

    await notifyNewProject(project, [...managers, ...areaManagers])

    return res.status(200).json({ message: 'Projeto criado com sucesso', project_id: project.id })
  } catch (err) {
    console.error('Webhook FreshService erro:', err)
    return res.status(500).json({ error: 'Erro ao processar webhook' })
  }
}

module.exports = { freshserviceWebhook }