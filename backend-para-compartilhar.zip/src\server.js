require('dotenv').config()
const app = require('./app')
const { startWeeklyReminderJob } = require('./jobs/weeklyReminder')

const PORT = process.env.PORT || 3000

app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`)
  startWeeklyReminderJob()
})