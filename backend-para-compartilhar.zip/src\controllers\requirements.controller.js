const prisma = require('../lib/prisma')
const logger = require('../lib/logger')
const touchProject = (project_id) =>
  prisma.project.update({ where: { id: project_id }, data: { updated_at: new Date() } })
const { syncMentions } = require('../services/mentions.service')
const { logActivity, ACTION_TYPES } = require('../services/activityLog.service')
const { needsApproval, canApprove, visibilityWhere, isFromTIArea } = require('../services/approvals.service')
const { hasPermission } = require('../services/rolePermissions.service')

const TI_AREA = 'Tecnologia da Informação'
const canMention = (requester, project) => {
  const isFromTI = requester.area === TI_AREA ||
    ['ANALISTA_MASTER', 'ANALISTA_TESTADOR'].includes(requester.role)
  const isResponsible = project.requesters?.some(
    r => r.user_id === requester.id && r.type === 'RESPONSAVEL'
  )
  return isFromTI && isResponsible
}

const getRequirement = async (req, res) => {
  try {
    const { project_id } = req.params
    const requester = req.user

    const project = await prisma.project.findUnique({ where: { id: project_id } })
    if (!project) {
      return res.status(404).json({ error: 'Projeto não encontrado' })
    }

    const requirement = await prisma.requirement.findFirst({
      where: { project_id, ...visibilityWhere(requester) },
      include: {
        author: { select: { id: true, name: true } },
        history: {
          orderBy: { edited_at: 'desc' },
          include: { editor: { select: { id: true, name: true } } }
        }
      }
    })

    if (!requirement) {
      return res.status(404).json({ error: 'Requisitos ainda não cadastrados para este projeto' })
    }

    return res.status(200).json(requirement)
  } catch (err) {
    logger.error(err)
    return res.status(500).json({ error: 'Erro ao buscar requisitos' })
  }
}

const createRequirement = async (req, res) => {
  try {
    const { project_id } = req.params
    const { content } = req.body
    const requester = req.user

    if (!content) {
      return res.status(400).json({ error: 'Campo obrigatório: content' })
    }
    if (!isFromTIArea(requester)) {
      return res.status(403).json({ error: 'Sem permissão para gerenciar requisitos' })
    }
    if (!(await hasPermission(requester, 'requirements.create'))) {
      return res.status(403).json({ error: 'Sem permissão para criar requisito' })
    }

    const project = await prisma.project.findUnique({
      where: { id: project_id },
      include: { members: true, requesters: true }
    })

    if (!project) {
      return res.status(404).json({ error: 'Projeto não encontrado' })
    }

    const isOwner = project.owner_id === requester.id
    const isMember = project.members.some(m => m.user_id === requester.id)
    const isResponsible = await prisma.projectRequester.findFirst({
      where: { project_id, user_id: requester.id, type: 'RESPONSAVEL' }
    })
    const isPrivileged = ['SUPERINTENDENTE', 'GERENTE', 'COORDENADOR', 'ANALISTA_MASTER', 'ANALISTA_TESTADOR'].includes(requester.role)

    if (!isOwner && !isMember && !isResponsible && !isPrivileged) {
      return res.status(403).json({ error: 'Sem permissão para criar requisitos neste projeto' })
    }

    const existing = await prisma.requirement.findFirst({ where: { project_id } })
    if (existing) {
      return res.status(400).json({ error: 'Requisitos já cadastrados. Use o método PATCH para atualizar.' })
    }

    const status = needsApproval(requester) ? 'AGUARDANDO_APROVACAO' : 'APROVADO'

    const requirement = await prisma.requirement.create({
      data: { project_id, author_id: requester.id, content, status },
      include: { author: { select: { id: true, name: true } } }
    })
    await touchProject(project_id)

    let mentionResult = { invalidUserIds: [] }
    if (status === 'APROVADO' && canMention(requester, project)) {
      mentionResult = await syncMentions({
        source_type: 'REQUIREMENT',
        source_id: requirement.id,
        project_id,
        text: content,
        requester,
      })
    }

    await logActivity({
      project_id,
      project_name: project.title,
      user_id: requester.id,
      action_type: ACTION_TYPES.REQUIREMENT_CREATED,
      description: `${requester.name} cadastrou os requisitos do projeto.`,
    })

    return res.status(201).json({ ...requirement, _mention_warning: mentionResult.invalidUserIds })
  } catch (err) {
    logger.error(err)
    return res.status(500).json({ error: 'Erro ao criar requisitos' })
  }
}

const updateRequirement = async (req, res) => {
  try {
    const { project_id } = req.params
    const { content } = req.body
    const requester = req.user

    if (!content) {
      return res.status(400).json({ error: 'Campo obrigatório: content' })
    }
    if (!isFromTIArea(requester)) {
      return res.status(403).json({ error: 'Sem permissão para gerenciar requisitos' })
    }
    if (!(await hasPermission(requester, 'requirements.edit'))) {
      return res.status(403).json({ error: 'Sem permissão para editar requisito' })
    }

    const project = await prisma.project.findUnique({
      where: { id: project_id },
      include: { members: true, requesters: true }
    })

    if (!project) {
      return res.status(404).json({ error: 'Projeto não encontrado' })
    }

    const isOwner = project.owner_id === requester.id
    const isMember = project.members.some(m => m.user_id === requester.id)
    const isResponsible = await prisma.projectRequester.findFirst({
      where: { project_id, user_id: requester.id, type: 'RESPONSAVEL' }
    })
    const isPrivileged = ['SUPERINTENDENTE', 'GERENTE', 'COORDENADOR', 'ANALISTA_MASTER', 'ANALISTA_TESTADOR'].includes(requester.role)

    if (!isOwner && !isMember && !isResponsible && !isPrivileged) {
      return res.status(403).json({ error: 'Sem permissão para editar requisitos neste projeto' })
    }

    const requirement = await prisma.requirement.findFirst({ where: { project_id } })
    if (!requirement) {
      return res.status(404).json({ error: 'Requisitos não encontrados para este projeto' })
    }

    if (needsApproval(requester) && requirement.status === 'APROVADO') {
      const pendingUpdate = await prisma.requirement.update({
        where: { id: requirement.id },
        data: { status: 'AGUARDANDO_APROVACAO', pending_action: 'EDITAR', pending_data: { content } },
        include: {
          author: { select: { id: true, name: true } },
          history: {
            orderBy: { edited_at: 'desc' },
            include: { editor: { select: { id: true, name: true } } }
          }
        }
      })
      await touchProject(project_id)
      return res.status(200).json(pendingUpdate)
    }

    if (needsApproval(requester) && requirement.status === 'AGUARDANDO_APROVACAO') {
      const pendingUpdate = await prisma.requirement.update({
        where: { id: requirement.id },
        data: { content },
        include: {
          author: { select: { id: true, name: true } },
          history: {
            orderBy: { edited_at: 'desc' },
            include: { editor: { select: { id: true, name: true } } }
          }
        }
      })
      await touchProject(project_id)
      return res.status(200).json(pendingUpdate)
    }

    await prisma.requirementHistory.create({
      data: {
        requirement_id: requirement.id,
        editor_id: requester.id,
        content_snapshot: requirement.content
      }
    })

    const updated = await prisma.requirement.update({
      where: { id: requirement.id },
      data: { content, status: 'APROVADO', pending_action: null, pending_data: null },
      include: {
        author: { select: { id: true, name: true } },
        history: {
          orderBy: { edited_at: 'desc' },
          include: { editor: { select: { id: true, name: true } } }
        }
      }
    })
    await touchProject(project_id)

    let mentionResult = { invalidUserIds: [] }
    if (canMention(requester, project)) {
      mentionResult = await syncMentions({
        source_type: 'REQUIREMENT',
        source_id: requirement.id,
        project_id,
        text: content,
        requester,
      })
    }

    await logActivity({
      project_id,
      user_id: requester.id,
      action_type: ACTION_TYPES.REQUIREMENT_UPDATED,
      description: `${requester.name} atualizou os requisitos do projeto.`,
    })

    return res.status(200).json({ ...updated, _mention_warning: mentionResult.invalidUserIds })
  } catch (err) {
    logger.error(err)
    return res.status(500).json({ error: 'Erro ao atualizar requisitos' })
  }
}

const approveRequirement = async (req, res) => {
  try {
    const { project_id } = req.params
    const requester = req.user

    if (!canApprove(requester)) {
      return res.status(403).json({ error: 'Sem permissão para aprovar requisitos' })
    }

    const requirement = await prisma.requirement.findFirst({ where: { project_id } })
    if (!requirement || requirement.status !== 'AGUARDANDO_APROVACAO') {
      return res.status(400).json({ error: 'Não há requisitos pendentes de aprovação' })
    }

    if (requirement.pending_action === 'EDITAR') {
      await prisma.requirementHistory.create({
        data: {
          requirement_id: requirement.id,
          editor_id: requirement.author_id,
          content_snapshot: requirement.content
        }
      })
      await prisma.requirement.update({
        where: { id: requirement.id },
        data: {
          content: requirement.pending_data.content,
          status: 'APROVADO',
          pending_action: null,
          pending_data: null,
        }
      })
    } else {
      await prisma.requirement.update({
        where: { id: requirement.id },
        data: { status: 'APROVADO', pending_action: null }
      })
    }

    await logActivity({
      project_id,
      user_id: requester.id,
      action_type: ACTION_TYPES.REQUIREMENT_UPDATED,
      description: `${requester.name} aprovou os requisitos do projeto.`,
    })

    return res.status(200).json({ message: 'Requisitos aprovados com sucesso' })
  } catch (err) {
    logger.error(err)
    return res.status(500).json({ error: 'Erro ao aprovar requisitos' })
  }
}

const rejectRequirement = async (req, res) => {
  try {
    const { project_id } = req.params
    const requester = req.user

    if (!canApprove(requester)) {
      return res.status(403).json({ error: 'Sem permissão para rejeitar requisitos' })
    }

    const requirement = await prisma.requirement.findFirst({ where: { project_id } })
    if (!requirement || requirement.status !== 'AGUARDANDO_APROVACAO') {
      return res.status(400).json({ error: 'Não há requisitos pendentes de aprovação' })
    }

    if (requirement.pending_action === 'EDITAR') {
      await prisma.requirement.update({
        where: { id: requirement.id },
        data: { status: 'APROVADO', pending_action: null, pending_data: null }
      })
    } else {
      await prisma.requirement.delete({ where: { id: requirement.id } })
    }

    return res.status(200).json({ message: 'Requisitos rejeitados' })
  } catch (err) {
    logger.error(err)
    return res.status(500).json({ error: 'Erro ao rejeitar requisitos' })
  }
}

module.exports = { getRequirement, createRequirement, updateRequirement, approveRequirement, rejectRequirement }